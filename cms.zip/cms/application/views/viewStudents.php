<?php include('inc/header.php'); ?>

	<div class="container mt-3">
		<h2 style="text-align: center;">VIEW STUDENT</h2>
		<?php echo anchor("admin/dashboard","Back",['class'=>'btn btn-primary']) ;?>
		<div class="row">
			<table class="table table-hover">
				<thead>
					<tr>
						<th scope="col">College Name</th>
						<th scope="col">Student Name</th>
						<th scope="col">Email</th>
						<th scope="col">Course</th>
						<th scope="col">Gender</th>
						<th scope="col">Branch</th>
						<th scope="col">Edit</th>
						<th scope="col">Remove</th>
					</tr>
				</thead>
				<tbody>
					<?php if(count($students)): ?>
						<?php foreach($students as $student): ?>
							<tr class="table-active">
								<td><?php echo $student->collegename; ?></td>
								<td><?php echo $student->studentname; ?></td>
								<td><?php echo $student->email; ?></td>
								<td><?php echo $student->course; ?></td>
								<td><?php echo $student->gender; ?></td>
								<td><?php echo $student->branch; ?></td>
								<td><?php echo anchor("admin/editStudent/{$student->student_id}","EDIT",['class'=>'buttons']) ;?></td>
								<td><?php echo anchor("admin/removeStudent/{$student->student_id}","REMOVE",['class'=>'buttons']) ;?></td>
							</tr>
					<?php endforeach;?>
					<?php else: ?>
						<tr>
							<td>No Record Found</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

	</div>
<?php include('inc/footer.php'); ?>	
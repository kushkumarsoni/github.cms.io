<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>College Management System</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>"/>
	<script src="<?php echo base_url('assets/js/jquery.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
	<style type="text/css">

		.buttons{
			/*color: #2196f3;*/
			border: 1px solid #cabdbd;
			border-radius: 5px;
			padding: 2px 10px 2px 10px;
			background-color: #007bff;
			color: white;
		}
		.buttons,a:hover{
			color: white;
			text-decoration: none;
		}
	</style>
	
</head>
<body>

	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
		<div class="container-fluid">
			<div class="navbar-header col-lg-10">
				<a class="navbar-brand" href="#" style="color: white;">COLLEGE MANAGEMENT SYSTEM</a>
			</div>
			<div class="col-lg-2" style="margin-top: 30px;" id="bs-example-navbar-collapse-2">

				<?php echo anchor("admin/dashboard","Dashboard",["class"=>"btn btn-danger"]); ?>
				<?php echo anchor("welcome/logout","Logout",["class"=>"btn btn-danger"]); ?>
			</div>
			<div class="dropdown-menu">
				<ul>
					<li>
						<?php echo anchor("admin/Co-Admin","View Co-Admin");?>
					</li>
				</ul>
			</div>
		</div>
		
	</nav>